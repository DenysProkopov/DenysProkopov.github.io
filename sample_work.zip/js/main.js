$(function(){
	
	new WOW().init();

	$('#mixitup-portfolio').mixItUp();

	$('.btn_menu').click(function(){
		$('.menu ul').slideToggle();
	});


	$("#menu,to_top").on("click","a", function (event) {
		event.preventDefault();
		var id  = $(this).attr('href'),
		top = $(id).offset().top;
		$('body,html').animate({scrollTop: top}, 2500);
	});

	$('.owl_carousel').owlCarousel({
		singleItem: true,
		navigation: true,
		navigationText: false

	});

});